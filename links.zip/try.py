def big():
    strin = "hidfhfhghfghjgfjghkghkhjlhjlhjlgfhgfkdfhfkdtjgfhcvbmcfgbv,ndghhjmdfgnnmb h dgmgmbvcvnmbh,mdfbhdmhfmdxfncgnfsngfndfgfnhfdndg"

    print(str(len(strin)))


    tech =[
    "Computing Information Technology", 
    "Medical Technology And Equipment" ,
    "Communications Technology" ,
    "Industrial and Manufacturing Technology" ,
    "Education Technology" ,
    "Construction Technology" ,
    "Aerospace Technology" ,
    "Biotechnology" ,
    "Agriculture Technology" ,
    "Electronics Technology" ,
    "Military Technology" ,
    "Robotics Technology" ,
    "Artificial Intelligence Technology" ,
    "Assistive Technology" ,
    "Entertainment Technology" ,
    "Sports Technology" ,
    "Vehicle Technology" ,
    "Environmental Technology" ,
    "3D Printing Technology" ,
        
    ]


    main_class = [
        "Science And Technology",
        "Celebrities And Gossip",
        "Vaccation , Wildlife and Earth",
        "Mortage , Property And House Items",
        "Investments And Business",
        "Relationships , Marriage and Parenting",
        "Health And Nutrition" ,
        "Agriculture and Food Security",
        "Sports"
        "Entertainment"
        
    ]
def fors():
    num = 1
    new =[]
    nos = [1 ,2 ,3 ,4]
    for x in nos:
        number = x
        if num  == number:
            new.append(number)
        else:
            pass
    print(new)
#fors()

def lo():
    name = "JAMES"
    name2 = name.lower() 
    print(name2)
lo()
            
        
    
    



