import random

import time
''''
x = ["james" , "jack" ]

print(x)


random.shuffle(x)

print(x)


names1 = x

names2 = ['mark' , "max" ]

names2.extend(x)


print(names2)


nos  = random.randint(0, 9)
full_arr = []
for x in range(0,6):
    
    nos  = random.randint(0, 9)
    
    full_arr.append(nos)


vc = random.randint(145346 , 976578)

print(vc)


now = time.time()


time.sleep(3)


now_now = time.time()


taken = now_now - now

print(taken) '''

def add():
    sun = 3 + 1
    
    #return sun
add()
print(add())